export default function Footer() {
    return (
      <footer className="w-full bg-blue-50 text-center text-sm text-gray-600 py-4 mt-auto border-t">
        © 2025 FieldBooking. All rights reserved.
      </footer>
    );
  }
  